<?php
phpinfo();
?>



